---
title: Reproductibilité et environnements de développement
author: Pol Dellaiera
location: Wébinaire recherche reproductible
date: 23 Mai 2025
options:
  incremental_lists: true
theme:
  override:
    footer:
      style: template
      center: "{title}"
      left: "{author}"
      right: "{current_slide}/{total_slides}"
      height: 1
---

<!-- jump_to_middle -->
<!-- alignment: center -->

# 👋 Introduction

<!-- end_slide -->

- Bonjour, merci !
- Curieux, passionné par l'informatique et la technologie
- Originaire de la région de Mons, en Belgique

![image:width:50%](images/Screenshot_20250522_142729.png)

- Consultant à la Commission Européenne à Bruxelles
- Collaborateur volontaire à l'Université de Mons
- À la limite du burn-out durant le COVID, j'ai entamé un master en informatique à l'université de Mons afin de m'aider à surmonter cette période difficile et occuper mon esprit différemment.

<!-- end_slide -->

Utilisateur de Linux depuis plus de 20 ans

![image:width:50%](images/Screenshot_20250522_150958.png)

<!-- alignment: center -->

Date de sortie: Nov 1998

<!-- end_slide -->

<!-- new_lines: 5 -->
<!-- alignment: center -->

![image:width:70%](images/Screenshot_20250522_151246.png)

Utilisateur de Linux au quotidien.

Pas très longtemps sous RedHat, quelques années sous Slackware, Gentoo, FreeBSD, et finalement NixOS depuis 2021.

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 💰 Carrière professionnelle

<!-- end_slide -->

<!-- new_lines: 10 -->

- Consultant externe à la Commission Européenne depuis 2012
  - Agence EISMEA (2012 -> 2015)
    - Développement de projets PHP
  - DG Digit (2015 -> 2025)
    - Développement de projets PHP open-source
    - Développement du PHP Competency Center
    - Recherche et développement de solutions pour des environnements de développement éphémères et reproductibles
    - Développement en Python et I.A.
  - DG EAC (2025 -> ...)
    - Architecte
    - DevOps

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 👐 Open Source

<!-- end_slide -->

<!-- new_lines: 5 -->

🧪 Contributeur Open Source depuis environ 2005.

<!-- pause -->

🫶 J'ai toujours aimé l'idée de collaborer de manière transparente et, d'une certaine manière, contribuer à un monde meilleur grâce à l'informatique ouverte et au partage de connaissances. L'open-source occupe donc une place importante dans ma vie. C'est aussi important pour moi de trouver une occupation que j'aime et pour laquelle je me sens utile.

<!-- pause -->

💊 En 2019-2020, je découvre la programmation fonctionnelle et je commence à programmer différemment grâce aux nouveaux concepts appris dans ce paradigme.

<!-- pause -->

❄️ C'est aussi à ce moment-là que je découvre Nix et NixOS et le monde fascinant de la reproductibilité.

<!-- pause -->

💡 Bien sûr, il m'a fallu du temps pour apprendre... et j'en apprends encore beaucoup tous les jours... et j'adore ça en fait !

<!-- pause -->

🎓 En 2021, je retourne à l'école pour obtenir un master en informatique à l'université de Mons. Ma thèse de master, sera sur la reproductibilité en ingénierie logicielle. Depuis juin 2024, le document est bien évidemment open-source et en accès libre. J'y ai apporté quelques modifications depuis.

<!-- pause -->

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 🤔 Pourquoi la reproductibilité ?

<!-- end_slide -->

## Envie de découvrir de nouvelles choses

- On en parlait de plus en plus autour de moi et je devais remplacer mon ordinateur portable...

## Envie de lier l'utile à l'agréable

- Pas d'environnements de travail adéquats, pas d'outils adéquats.
- Solutions proposées totalement inadaptées
- L'utilisation de son propre ordinateur était souvent plus efficace
- Projets avec beaucoup trop de prérequis et d'assomptions implicites
- Pas de vision à long terme.
- _etc etc_...

## Et donc?

- Je me suis rendu compte que la reproductibilité est un sujet essentiel dans le développement de logiciels
- Beaucoup de problèmes rencontrés dans le cadre de mon travail pourraient être résolus en implémentant des processus reproductibles.
- L'informatique moderne devrait être pensée de manière à ce que les choses soient reproductibles **par défaut**.

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

> _If everyone on a research team knows that everything they do is going to someday be published for reproducibility , they'll behave differently from day one._
>
> 2009, Donoho et al., [](https://doi.org/10.1109/MCSE.2009.15)

<!-- end_slide -->
<!-- jump_to_middle -->

## L'utile vers l'agréable

- De frustrations... vers une solution
- Adoption de Nix, une solution initialement européenne !
- Écriture de ma thèse de master sur ce sujet.

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 📖 Reproducibility In Software Engineering

<!-- end_slide -->

<!-- alignment: center -->

![image:width:100%](images/Screenshot_20250522_193221.png) [](https://doi.org/10.5281/zenodo.12666898)

<!-- end_slide -->

<!-- alignment: center -->

![image:width:100%](images/Screenshot_20250523_103303.png) [](https://codeberg.org/p1ld7a/master-thesis)

<!-- end_slide -->

<!-- alignment: center -->

![image:width:100%](images/Screenshot-2025-05-22-at-19-35-07.png) [](https://github.com/drupol/master-thesis)

<!-- end_slide -->

<!-- new_lines: 5 -->

## Reproducibility In Software Engineering

- Initialement un repository privé, partagé avec mon superviseur Tom Mens
- Reproductible par défaut, avec environnement de développement
- Écrite avec Typst, une alternative moderne à LaTeX
- Composition
  - Introduction
  - Reproductibilité
    - Partie théorique
    - Historique
    - Définitions
    - Importance
  - Évaluation logicielle
    - Partie pratique
    - Pas d'outils
    - Docker
    - Guix
    - Nix
  - Conclusion

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 🛠️ Environnements Reproductibles

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

> Tout comme on dort toujours mieux dans son propre lit, ...

<!-- pause -->

> On est toujours plus efficace dans un environnement de travail familier et avec ses propres outils.

<!-- end_slide -->

<!-- new_lines: 5 -->

<!-- column_layout: [1, 1] -->

<!-- column: 0 -->

## Le passé

- Approche convergente qui rétablit au mieux une situation donnée en cas de divergence
- Systèmes muables

<!-- new_lines: 1 -->

- Exemples de solutions
  - "_dotfiles_"
  - Puppet
  - Chef
  - Ansible

<!-- column: 1 -->

## Le futur

- Approche congruente où on ne laisse pas de place à l'improvisation
- Systèmes immuables

<!-- new_lines: 1 -->

- Exemples de solutions
  - Nix
  - Guix

<!-- end_slide -->

## Et Docker/Podman?

- Ces outils permettent de construire et d'interpréter des images de conteneurs
- Ces images sont immuables certes, mais pas forcément reproductibles
- L'utilisation de ces outils ne garantit pas la reproductibilité
  - Pas de garantie que l'environnement de développement soit le même sur toutes les machines
  - Pas de garantie que l'environnement de production soit le même sur toutes les machines

## Pourquoi?

```docker {all|4-5} +line_numbers
FROM buildpack-deps:bookworm
# ...
RUN set -eux; \
    apt-get update; \
    apt-get install -y --no-install-recommends \
        libbluetooth-dev \
        tk-dev \
        uuid-dev \
    ; \
    rm -rf /var/lib/apt/lists/*
# ...
```

Un extrait du Dockerfile utilisé pour construire **l'image officielle** de Python.

<!-- end_slide -->

<!-- jump_to_middle -->

## Environnements de Développement Reproductibles

- Partons de l'hypothèse qu'un environnement de développement est le résultat d'un build
- Nix est un builder performant qui me permet de partager des "_builds_"
- Si ça marche sur ma machine, il y a de fortes chances que ça marche ailleurs
- Grâce à une syntaxe principalement déclarative, pas de dépendances implicites ou cachées
- Force les développeurs à déclarer les dépendances de leurs projets, à mieux connaître et comprendre leurs outils

<!-- end_slide -->

<!-- jump_to_middle -->
<!-- alignment: center -->

# 🤗 Demo

<!-- end_slide -->

## Demo 1 - Les devShells

- Créer un environnement de développement reproductible
- Contenant les logiciels:
  - PHP
  - Typst

<!-- end_slide -->

## Méthode historique (demo-1-a)

```nix +line_numbers {all|1-6|7-12}
# shell.nix
{
  pkgs ? import (fetchTarball {
    url = "https://github.com/NixOS/nixpkgs/archive/e314d5c6d3b3a0f40ec5bcbc007b0cbe412f48ae.tar.gz";
    sha256 = "049zgk55rk6x3m0v7xdcabnayc0l1rbbfvfg9fr9ky92f9g2wl12";
    }) { }
}:
pkgs.mkShell {
  packages = [
    pkgs.php
    pkgs.typst
  ];
}
```

<!-- pause -->

```bash +exec
nix-shell ./demos/demo-1-a/ --run "php --version"

nix-shell ./demos/demo-1-a/ --run "typst --version"
```

<!-- end_slide -->

## Méthode expérimentale - Flake sans framework (demo-1-b)

```nix +line_numbers {all|8-9}
# flake.nix
{
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixpkgs-unstable";
  };

  outputs = inputs:
    let
      system = "x86_64-linux";
      pkgs = import inputs.nixpkgs { inherit system; };
    in
    {
      devShells.${system}.mon-php-shell = pkgs.mkShell {
        packages = [
          pkgs.php
          pkgs.typst
        ];
      };
    };
}
```

<!-- pause -->

```bash +exec
nix flake show ./demos/demo-1-b
```

<!-- end_slide -->

## Méthode expérimentale - Flake avec framework (demo-1-c)

```nix +line_numbers
# flake.nix
{
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixpkgs-unstable";
    flake-parts.url = "github:hercules-ci/flake-parts";
  };

  outputs = inputs: inputs.flake-parts.lib.mkFlake { inherit inputs; } {
    systems = [ "x86_64-linux" "x86_64-darwin" "aarch64-linux" "aarch64-darwin" ];

    perSystem = { pkgs, ... }: {
      devShells.mon-php-shell = pkgs.mkShell {
        packages = [
          pkgs.php
          pkgs.typst
        ];
      };
    };
  };
}
```

<!-- pause -->

```bash +exec
nix flake show ./demos/demo-1-c
```

<!-- end_slide -->

## Demo 2 - Profiles Utilisateurs avec Home Manager

<!-- jump_to_middle -->
<!-- alignment: center -->

Live demo

Projets montrés:
  - [](https://code.europa.eu/ecphp/devs-profile/)
  - [](https://code.europa.eu/pol/ec-lib/)

<!-- end_slide -->

![image:width:100%](images/Screenshot_20250522_214436.png)
