# Presenterm Presentations

## Usage

`nix flake show` to list the available artefacts.

`nix develop` to enter the development shell.

`nix run .#<name>` to run a specific presentation. Where `<name>` is the name of a directory in the `src` directory.
